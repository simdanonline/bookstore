import { Ionicons } from "@expo/vector-icons";
import React from "react";
import {
  Image,
  ImageBackground,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
  Dimensions,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { AppNavigationProps } from "../../../types";
import * as LocalAuthentication from "expo-local-authentication";
import { displayError, RFPercentage, RFValue } from "../../Utils/Utils";
import Colors from "../../constants/Colors";
import {
  ScaledSheet,
  scale,
  verticalScale,
  moderateScale,
} from "react-native-size-matters";

interface Props {}

const { width } = Dimensions.get("window");

const LoginScreen = ({ navigation }: AppNavigationProps<any>) => {
  const [hidePassword, setHidePassword] = React.useState(true);

  const useBio = async () => {
    try {
      const hasBio = await LocalAuthentication.hasHardwareAsync();
      if (!hasBio) {
        return displayError("No bio metrics found");
      }
      const isEnrolled = await LocalAuthentication.isEnrolledAsync();
      if (!isEnrolled) {
        return displayError("You have not setup biometrics on your device");
      }
      const auth = await LocalAuthentication.authenticateAsync({
        promptMessage: "Login using biometrics",
      });
      if (auth.success) {
        navigation.navigate("HomePage");
      }
      console.log(auth);
    } catch (error) {}
  };
  return (
    <SafeAreaView style={styles.container}>
      <ImageBackground
        source={require("../../assets/img/Rectangle.png")}
        style={{ flex: 1 }}
      >
        <Image
          source={require("../../assets/img/top_right_corner.png")}
          style={styles.topLeftCorner}
        />
        <Image
          source={require("../../assets/img/middlecurve.png")}
          style={styles.middle}
        />
        <Image
          source={require("../../assets/img/beside_middlecurve.png")}
          style={styles.beside_middlecurve}
        />
        <Image
          source={require("../../assets/img/beside_adeventure.png")}
          style={styles.beside_adeventure}
        />
        <View style={styles.heroTextContainer}>
          <Text style={styles.heroText}>Adventures in literature.</Text>
          <Text style={styles.join}>Join our community</Text>
        </View>
        <View style={styles.formWrapper}>
          <Text style={styles.loginText}>Log in</Text>
          <View style={styles.inputContainer}>
            <TextInput
              placeholder="Email"
              style={styles.input}
              keyboardType="email-address"
              placeholderTextColor={Colors.color1}
            />
          </View>
          <View style={styles.passwordSection}>
            <TextInput
              placeholder="Password"
              style={styles.passwordInput}
              placeholderTextColor={Colors.color1}
              secureTextEntry={hidePassword}
            />
            <Ionicons
              name={hidePassword ? "eye-outline" : "eye-off-outline"}
              style={styles.eyeIcon}
              size={20}
              onPress={() => setHidePassword(!hidePassword)}
              color={Colors.iconColor}
            />
          </View>
          <TouchableOpacity
            style={styles.signBtn}
            onPress={() => navigation.navigate("HomePage")}
          >
            <Text style={styles.signInText}>Sign in</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.fingerPrint} onPress={useBio}>
            <Ionicons name="finger-print-sharp" size={30} />
          </TouchableOpacity>
        </View>
      </ImageBackground>
    </SafeAreaView>
  );
};

export default LoginScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  formWrapper: {
    borderWidth: 1,
    borderColor: Colors.white,
    position: "absolute",
    bottom: 0,
    right: 0,
    left: 0,
    backgroundColor: Colors.white,
    paddingHorizontal: RFValue(42),
    borderTopLeftRadius: 32,
    borderTopRightRadius: 32,
  },
  input: {
    borderWidth: 1,
    paddingTop: RFValue(15),
    paddingBottom: RFValue(15),
    borderColor: Colors.borderColor,
    paddingLeft: RFValue(22),
    borderRadius: 12,
    color: Colors.color1,
  },
  passwordInput: {
    flex: 1,
    borderWidth: 0,
    paddingTop: RFValue(16),
    paddingBottom: RFValue(15),
    paddingLeft: RFValue(22),
    paddingRight: RFValue(10),
    color: Colors.color1,
  },
  inputContainer: {},
  loginText: {
    fontSize: RFValue(16),
    fontFamily: "poppins600",
    paddingTop: RFValue(37),
    paddingBottom: RFValue(20),
    lineHeight: RFValue(24),
    color: Colors.color1,
  },
  signInText: {
    textAlign: "center",
    fontSize: RFValue(16),
    fontFamily: "poppins500",
    lineHeight: RFValue(23.36),
    color: Colors.white,
    paddingVertical: RFValue(12),
  },
  signBtn: {
    backgroundColor: Colors.black,
    borderRadius: 15,
  },
  fingerPrint: {
    alignSelf: "center",
    marginVertical: RFValue(30),
  },
  passwordSection: {
    flex: 1,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: Colors.white,
    marginVertical: RFValue(20),
    borderWidth: 1,
    borderColor: Colors.borderColor,
    borderRadius: 12,
  },
  eyeIcon: {
    padding: 10,
  },
  heroText: {
    fontSize: RFValue(24),
    lineHeight: RFValue(29.5),
    fontFamily: "poppins600",
    width: RFValue(148),
    color: Colors.color2,
  },
  join: {
    color: Colors.color3,
    marginBottom: RFValue(75),
    marginTop: RFValue(35),
  },
  heroTextContainer: {
    position: "absolute",
    top: RFValue(205),
    left: RFValue(28),
  },
  topLeftCorner: {
    position: "absolute",
    top: 0,
    left: 0,
    height: RFValue(150),
    width: RFValue(70),
    borderWidth: 0,
    borderColor: "red",
    opacity: 0.1,
  },
  middle: {
    position: "absolute",
    width: RFValue(130 * 0.8),
    height: RFValue(130 * 0.8),
    left: RFValue(width / 2 - 65),
    top: RFValue(80),
    opacity: 0.1,
  },
  beside_middlecurve: {
    position: "absolute",
    left: RFValue(width / 2),
    top: 0,
    opacity: 0.1,
  },
  beside_adeventure: {
    position: "absolute",
    left: RFValue(width * 0.4),
    opacity: 0.1,
    top: RFValue(200),
  },
});
