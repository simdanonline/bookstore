import { Fontisto, Ionicons, MaterialCommunityIcons } from "@expo/vector-icons";
import React from "react";
import {
  Dimensions,
  Image,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { AppNavigationProps } from "../../../types";
import Colors from "../../constants/Colors";
import { Rating, AirbnbRating } from "react-native-ratings";

interface Props {}

const { width } = Dimensions.get("window");

const SelectedBook = ({ route, navigation }: AppNavigationProps<any>) => {
  // @ts-ignore
  const { book } = route.params;
  return (
    <SafeAreaView style={{ backgroundColor: Colors.pageBg, flex: 1 }}>
      <ScrollView>
        <View style={styles.headerContainer}>
          <View>
            <TouchableOpacity onPress={() => navigation.goBack()}>
              <Ionicons name="chevron-back-outline" size={30} />
            </TouchableOpacity>
          </View>
          <View style={{ flexDirection: "row", alignItems: "center" }}>
            <Fontisto name="bookmark" size={20} style={{ paddingRight: 30 }} />
            <MaterialCommunityIcons name="dots-vertical" size={20} />
          </View>
        </View>
        <View>
          <Image source={{ uri: book.image }} style={styles.image} />
          <View>
            <Text style={styles.bookTitle}>{book.title} </Text>
            <Text style={styles.bookSubtitle}>{book.subtitle} </Text>
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "center",
                paddingBottom: 15,
              }}
            >
              <AirbnbRating
                count={5}
                reviews={["Terrible", "Bad", "Meh", "OK", "Good"]}
                defaultRating={4}
                size={20}
                showRating={false}
                isDisabled={true}
              />
              <Text
                style={{
                  fontSize: 14,
                  fontFamily: "poppins500",
                  color: Colors.color1,
                  paddingLeft: 10,
                  lineHeight: 21,
                }}
              >
                <Text>4.5</Text>
                <Text style={{ opacity: 0.5 }}>/5.0</Text>
              </Text>
            </View>
            <Text style={styles.bookDesc}>
              A spectacular visual journey through 40 years of haute couture
              from one of the best-known and most trend-setting brands in
              fashion.
            </Text>
          </View>

          <View>
            <View>
              <View style={styles.btnContainer}>
                <View style={styles.pageBtn}>
                  <Image
                    source={require("../../assets/img/Vector.png")}
                    style={styles.menuIcon}
                  />
                  <Text style={styles.btnText}>Preview</Text>
                </View>
                <View style={styles.pageBtn}>
                  <Ionicons name="ios-chatbubble-ellipses-outline" size={22} />
                  <Text style={styles.btnText}>Reviews</Text>
                </View>
              </View>
            </View>
          </View>

          <TouchableOpacity style={styles.buyBtn}>
            <Text style={styles.buyText}>Buy Now for $46.99</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

export default SelectedBook;

const styles = StyleSheet.create({
  headerContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingHorizontal: 30,
    paddingTop: 30,
  },
  image: {
    height: 320,
    width: 216,
    alignSelf: "center",
  },
  bookTitle: {
    fontSize: 24,
    fontFamily: "poppins600",
    textAlign: "center",
    paddingHorizontal: width * 0.1,
    color: Colors.color1,
  },
  bookSubtitle: {
    textAlign: "center",
    fontFamily: "poppins500",
    fontSize: 14,
    color: Colors.color1,
    lineHeight: 21,
    paddingVertical: 10,
    opacity: 0.5,
  },
  bookDesc: {
    paddingHorizontal: width * 0.1,
    textAlign: "center",
    fontFamily: "poppins400",
    fontSize: 14,
    lineHeight: 24,
    opacity: 0.5,
    color: Colors.color1,
  },
  menuIcon: {
    width: 18,
    height: 13,
    backgroundColor: "#fff",
  },
  pageBtn: {
    flexDirection: "row",
    backgroundColor: "#fff",
    paddingVertical: 10,
    justifyContent: "center",
    paddingHorizontal: 35,
    alignItems: "center",
    borderRadius: 8,

    shadowColor: "rgba(0,0,0,0.1)",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.8,
    shadowRadius: 1,
    elevation: 1,
  },
  btnText: {
    fontSize: 14,
    fontFamily: "poppins500",
    lineHeight: 24,
    paddingLeft: 15,
  },
  btnContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-around",
    marginTop: 20,
  },
  buyBtn: {
    backgroundColor: Colors.black,
    paddingVertical: 18,
    marginHorizontal: 20,
    marginTop: 35,
    borderRadius: 16,
  },
  buyText: {
    color: Colors.white,
    textAlign: "center",
    lineHeight: 24,
    fontSize: 16,
    fontFamily: "poppins500",
  },
});
