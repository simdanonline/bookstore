import { Feather } from "@expo/vector-icons";
import React from "react";
import { Image, ScrollView, StyleSheet, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { AppNavigationProps } from "../../../types";
import bookApi from "../../api/bookApi";
import BookView from "../../components/BookView";
import LoadingView from "../../components/LoadingView";
import NavBar from "../../components/NavBar";
import NewestBooks from "../../components/NewestBooks";
import Colors from "../../constants/Colors";
import { displayError } from "../../Utils/Utils";

interface Props {}
export interface BookType {
  title: string;
  subtitle: string;
  price: string;
  image: string;
}

const HomePage = ({ navigation }: AppNavigationProps<any>) => {
  const [books, setBooks] = React.useState<BookType[]>([]);
  const [newBooks, setNewBooks] = React.useState<BookType[]>([]);
  const [isLoading, setIsLoading] = React.useState<boolean>(true);

  React.useEffect(() => {
    (async () => {
      try {
        const { data } = await bookApi.get("/search/fashion");
        const { data: newBook } = await bookApi.get("/new");
        setBooks(data.books);
        setNewBooks(newBook.books);
        setIsLoading(false);
      } catch (error) {
        displayError(error.message);
      }
    })();
  }, []);

  const onPressBook = (book: BookType) => {
    navigation.navigate("SelectedBook", { book });
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.headerContainer}>
          <View style={styles.headerItems}>
            <View style={styles.imgAndText}>
              <Image
                source={require("../../assets/img/camera_boy.png")}
                style={{
                  width: 40,
                  height: 40,
                }}
              />
              <Text style={styles.dustin}>Hi, Dustin!</Text>
            </View>
            <Feather name="search" size={25} />
          </View>
        </View>
        <View>
          <Text style={styles.popularBooks}>Popular Books</Text>
        </View>
        <View>
          <ScrollView horizontal={true} showsHorizontalScrollIndicator={false}>
            {books.map((book, idx) => {
              return (
                <React.Fragment key={idx}>
                  <BookView book={book} onPress={onPressBook} />
                </React.Fragment>
              );
            })}
          </ScrollView>
          <View>
            <Text style={styles.popularBooks}>Newest</Text>
          </View>
          <View style={{}}>
            {newBooks.map((book, idx) => {
              return (
                <View key={idx}>
                  <NewestBooks book={book} onPress={onPressBook} />
                </View>
              );
            })}
          </View>
        </View>
        <LoadingView shown={isLoading} />
      </ScrollView>
      <View style={{ backgroundColor: "transparent" }}>
        <NavBar />
      </View>
    </SafeAreaView>
  );
};

export default HomePage;

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: 30,
    flex: 1,
    backgroundColor: "#fff",
  },
  headerItems: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  imgAndText: {
    flexDirection: "row",
    alignItems: "center",
  },
  headerContainer: {
    paddingTop: 30,
  },
  dustin: { paddingLeft: 12, fontFamily: "poppins600", color:Colors.color1 },
  popularBooks: {
    fontFamily: "poppins600",
    fontSize: 24,
    paddingTop: 40,
    paddingBottom: 10,
    color:Colors.color1
  },
});
