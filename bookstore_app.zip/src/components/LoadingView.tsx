import React from "react";
import LottieView from "lottie-react-native";
import { View } from "react-native";
import Modal from "react-native-modal";

interface Props {
  shown: boolean;
}

const LoadingView = ({ shown }: Props) => {
  return (
    <React.Fragment>
      <Modal isVisible={shown}>
        <View
          style={{
            borderWidth: 0,
            alignItems: "center",
            justifyContent:"center"
            // width: width * 0.6,
          }}
        >
          <LottieView
            style={{
              width: 150,
              height: 150,
              backgroundColor: "transparent",
              alignSelf: "center",
            }}
            source={require("../assets/json/books.json")}
            autoPlay
            loop
          />
        </View>
      </Modal>
    </React.Fragment>
  );
};

export default LoadingView;
