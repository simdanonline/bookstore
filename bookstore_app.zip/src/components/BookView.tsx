import React from "react";
import { Image, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import Colors from "../constants/Colors";
import { BookType } from "../screens/HomePage/HomePage";

interface Props {
  book: BookType;
  onPress: (book:BookType) => void;
}

const BookView = ({ book, onPress }: Props) => {
  return (
    <React.Fragment>
      <TouchableOpacity style={{ flexDirection: "column" }} onPress={() => onPress(book)}>
        <View>
          <Image source={{ uri: book.image }} style={styles.image} />
        </View>
        <Text style={styles.bookName}>
          {book.title.substring(0, 30) +
            `${book.title.length > 30 ? "..." : ""}`}{" "}
        </Text>
        <Text style={styles.bookSubtitle}>
          {book.subtitle.substring(0, 30) +
            `${book.subtitle.length > 30 ? "..." : ""}`}{" "}
        </Text>
      </TouchableOpacity>
    </React.Fragment>
  );
};

export default BookView;

const styles = StyleSheet.create({
  image: {
    width: 126,
    height: 192,
    resizeMode: "cover",
    borderWidth: 0,
  },
  bookName: {
    width: 100,
    fontFamily: "poppins600",
    fontSize: 16,
    lineHeight: 24,
    color: Colors.color1
  },
  bookSubtitle: {
    fontFamily: "poppins500",
    width: 126,
    fontSize: 12,
    paddingVertical: 5,
    lineHeight: 18,
    color: Colors.color1,
    opacity: 0.5
  },
});
