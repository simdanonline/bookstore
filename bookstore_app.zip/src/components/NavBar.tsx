import { AntDesign, Feather, Fontisto } from "@expo/vector-icons";
import { Card } from "native-base";
import React from "react";
import { View } from "react-native";
import StaticTabbar from "./StaticBar";

interface Props {}

const NavBar = (props: Props) => {
  return (
    <React.Fragment>
      <Card
        style={{
          borderWidth: 0,
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "space-evenly",
          borderRadius: 22,
          paddingVertical: 22,
        }}
      >
        <Feather name="home" size={30} color={"#000"} />
        <Fontisto name="bookmark" size={30} color={"rgba(0,0,0,0.5)"} />
        <AntDesign name="shoppingcart" size={30} color={"rgba(0,0,0,0.5)"} />
        <AntDesign name="setting" size={30} color={"rgba(0,0,0,0.5)"} />
      </Card>
    </React.Fragment>
  );
};

export default NavBar;
